﻿--Câu 1: Tạo CSDL QLDIEM--
Create database QLDIEM 
create table SinhVien(
MaSV char(5) not null primary key,
Hoten nvarchar(20),
Ngaysinh date)
create table MonHoc(
MaMon char(5) not null primary key,
TenMH nvarchar(20),
SoTC int)
create table Diem(
MaSV char(5) not null constraint fk_MaSV references Sinhvien(MaSV),
MaMon char(5) not null constraint fk_MaMH references MonHoc(MaMon),
DiemThi decimal
)

-----Nhập dữ liệu vào bảng-----

insert SinhVien values
('001', 'Vu Nguyen', '2002-3-12'),
('002', 'Fleur', '2002-06-12'),
('003', 'Hibiscus', '2000-06-20')

insert MonHoc values
('MH1', 'LT', '3'),
('MH2', 'HT', '3'),
('MH3', 'LM', '2')

insert Diem values
('001', 'MH3', '0'),
('002', 'MH1', '10'),
('001', 'MH2', '10'),
('003', 'MH2', '1'),
('003', 'MH1', '10')
--Selcect xem du lieu bang--
SELECT *  
FROM Diem;

SELECT *  
FROM MonHoc;
SELECT *  
FROM SinhVien;
--2.Hàm thống kê sinh viên có điểm < 5 với môn học được nhập từ bàn phím--
GO
create function thongke (@tmh nvarchar(20))
returns int
as
begin
 declare @dem int
 set @dem = (select count(@tmh) from Diem join MonHoc on MonHoc.MaMON = Diem.MaMON where Diem.DiemThi<5)
 return @dem
end
GO
select dbo.thongke('HT')

--3.Tạo thủ tục thêm mới một dòng vào bảng Diem với dữ liệu nhập từ bàn phím, kiểm tra tên môn học có trong bảng môn học không--
go
create procedure nhapDiem(@MaSV char(5),@MaMon char(5), @DiemThi float)
as
insert into Diem(MaSV,MaMon,Diemthi) values(@MaSV,@MaMon,@DiemThi)
go
nhapDiem '003','MH3',9
go
--4.Tạo trigger khi thêm mới hay sửa dữ liệu bảng Diem thì kiểm tra điểm có nằm trong khoảng 0 đến 10 không--
create trigger them_sua
on Diem
FOR  INSERT, UPDATE
AS
if(select DiemThi From inserted)>10 and (select DiemThi From inserted)<0
begin
print
'khong cho phep'
rollback transaction
end
insert into Diem
values ('SV1','MM3','2')